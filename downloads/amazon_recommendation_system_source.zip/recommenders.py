"""
Traditional recommendation algorithms for the Amazon ratings dataset.

Implements three progressively more sophisticated approaches, which is a
common structure for a recommendation-system portfolio project:

1. Popularity-based       -> non-personalized baseline
2. Item-based collaborative filtering (cosine similarity)
3. Matrix factorization (truncated SVD via scipy)

Each model exposes a `recommend(user_id, n)` method and the module includes
an evaluation routine (RMSE for the rating-prediction task).
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix
from scipy.sparse.linalg import svds
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error


# ---------------------------------------------------------------------------
# Utility: build the user-item matrix
# ---------------------------------------------------------------------------
def build_user_item_matrix(df: pd.DataFrame) -> pd.DataFrame:
    """Pivot ratings into a dense user x product matrix (missing -> 0)."""
    matrix = df.pivot_table(index="userId", columns="productId", values="Rating").fillna(0)
    return matrix


# ---------------------------------------------------------------------------
# 1. Popularity-based recommender (baseline)
# ---------------------------------------------------------------------------
class PopularityRecommender:
    def __init__(self, min_ratings: int = 5):
        self.min_ratings = min_ratings
        self.ranking_ = None

    def fit(self, df: pd.DataFrame):
        agg = df.groupby("productId")["Rating"].agg(["mean", "count"])
        agg = agg[agg["count"] >= self.min_ratings]
        # Weighted score balances average rating with popularity (like IMDB's
        # weighted rating) so a product with a single 5-star review doesn't
        # outrank one with thousands of consistently high ratings.
        C = agg["mean"].mean()
        m = self.min_ratings
        agg["score"] = (agg["count"] / (agg["count"] + m)) * agg["mean"] + (
            m / (agg["count"] + m)
        ) * C
        self.ranking_ = agg.sort_values("score", ascending=False)
        return self

    def recommend(self, user_id=None, n: int = 10) -> list:
        # Non-personalized: same top-N list for everyone.
        return list(self.ranking_.head(n).index)


# ---------------------------------------------------------------------------
# 2. Item-based collaborative filtering
# ---------------------------------------------------------------------------
class ItemBasedCF:
    def __init__(self, k_neighbors: int = 20):
        self.k_neighbors = k_neighbors
        self.user_item = None
        self.item_sim = None

    def fit(self, df: pd.DataFrame):
        self.user_item = build_user_item_matrix(df)
        sparse_matrix = csr_matrix(self.user_item.values)
        sim = cosine_similarity(sparse_matrix.T)  # item-item similarity
        self.item_sim = pd.DataFrame(
            sim, index=self.user_item.columns, columns=self.user_item.columns
        )
        return self

    def recommend(self, user_id, n: int = 10) -> list:
        if user_id not in self.user_item.index:
            return []

        user_ratings = self.user_item.loc[user_id]
        rated_items = user_ratings[user_ratings > 0].index

        scores = pd.Series(dtype=float)
        for item in rated_items:
            sim_items = self.item_sim[item].drop(index=rated_items, errors="ignore")
            top_sim = sim_items.sort_values(ascending=False).head(self.k_neighbors)
            scores = scores.add(top_sim * user_ratings[item], fill_value=0)

        return list(scores.sort_values(ascending=False).head(n).index)

    def predict_rating(self, user_id, product_id) -> float:
        if user_id not in self.user_item.index or product_id not in self.item_sim.index:
            return np.nan
        user_ratings = self.user_item.loc[user_id]
        rated_items = user_ratings[user_ratings > 0].index
        rated_items = rated_items.drop(product_id, errors="ignore")
        if len(rated_items) == 0:
            return np.nan
        sims = self.item_sim.loc[product_id, rated_items]
        if sims.abs().sum() == 0:
            return np.nan
        return float((sims * user_ratings[rated_items]).sum() / sims.abs().sum())


# ---------------------------------------------------------------------------
# 3. Matrix factorization (SVD)
# ---------------------------------------------------------------------------
class SVDRecommender:
    def __init__(self, n_factors: int = 20):
        self.n_factors = n_factors
        self.user_item = None
        self.pred_df = None

    def fit(self, df: pd.DataFrame):
        self.user_item = build_user_item_matrix(df)
        matrix = self.user_item.values
        user_means = matrix.mean(axis=1)
        matrix_demeaned = matrix - user_means.reshape(-1, 1)

        k = min(self.n_factors, min(matrix_demeaned.shape) - 1)
        U, sigma, Vt = svds(matrix_demeaned, k=k)
        sigma = np.diag(sigma)

        all_pred = U @ sigma @ Vt + user_means.reshape(-1, 1)
        self.pred_df = pd.DataFrame(
            all_pred, index=self.user_item.index, columns=self.user_item.columns
        )
        return self

    def recommend(self, user_id, n: int = 10) -> list:
        if user_id not in self.pred_df.index:
            return []
        already_rated = self.user_item.loc[user_id]
        already_rated = already_rated[already_rated > 0].index
        preds = self.pred_df.loc[user_id].drop(index=already_rated, errors="ignore")
        return list(preds.sort_values(ascending=False).head(n).index)

    def predict_rating(self, user_id, product_id) -> float:
        if user_id not in self.pred_df.index or product_id not in self.pred_df.columns:
            return np.nan
        return float(self.pred_df.loc[user_id, product_id])


# ---------------------------------------------------------------------------
# Evaluation
# ---------------------------------------------------------------------------
def train_test_split_ratings(df: pd.DataFrame, test_size: float = 0.2, random_state: int = 42):
    return train_test_split(df, test_size=test_size, random_state=random_state)


def evaluate_rmse(model, test_df: pd.DataFrame) -> float:
    """RMSE of predicted vs. actual ratings on held-out interactions."""
    preds, actuals = [], []
    for row in test_df.itertuples(index=False):
        pred = model.predict_rating(row.userId, row.productId)
        if not np.isnan(pred):
            preds.append(pred)
            actuals.append(row.Rating)
    if not preds:
        return float("nan")
    return float(np.sqrt(mean_squared_error(actuals, preds)))


def precision_at_k(model, test_df: pd.DataFrame, k: int = 10, rating_threshold: float = 4.0) -> float:
    """
    Fraction of top-k recommended items (per user) that the user actually
    rated >= rating_threshold in the held-out test set.
    """
    hits, total = 0, 0
    for user_id, group in test_df.groupby("userId"):
        relevant = set(group[group["Rating"] >= rating_threshold]["productId"])
        if not relevant:
            continue
        recs = set(model.recommend(user_id, n=k))
        hits += len(recs & relevant)
        total += k
    return hits / total if total else float("nan")
