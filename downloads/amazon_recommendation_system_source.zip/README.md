# Amazon Product Recommendation System

A traditional machine-learning recommendation engine built on Amazon's
product-ratings data, demonstrating three progressively more sophisticated
approaches used in real-world e-commerce systems (Amazon's own production
system famously uses item-to-item collaborative filtering).

## Business Problem

E-commerce platforms need to surface relevant products to each user out of
a catalog of millions of items. This project simulates that problem end to
end: from raw, extremely sparse user-item interaction data, to a working,
evaluated recommendation engine.

## Dataset

**Amazon Product Reviews (Electronics)** — Kaggle
https://www.kaggle.com/datasets/saurav9786/amazon-product-reviews

Columns: `userId`, `productId`, `Rating` (1–5), `timestamp`

> Download the CSV from Kaggle and place it at `data/ratings_Electronics.csv`
> before running the pipeline (not included in this repo due to size/license).

## Approach

| Step | Description |
|---|---|
| **1. EDA** | Rating distribution, ratings-per-user and ratings-per-product (long-tail / power-law shape typical of e-commerce), sparsity analysis |
| **2. Preprocessing** | Filter to active users (≥5 ratings) and popular products (≥10 ratings) to make collaborative filtering tractable and reduce noise |
| **3. Popularity Baseline** | Non-personalized ranking using a Bayesian-weighted rating (balances average score and volume, same idea as IMDB's weighted rating) |
| **4. Item-Based Collaborative Filtering** | Cosine similarity between products based on shared user ratings; recommends products similar to what a user already liked |
| **5. Matrix Factorization (SVD)** | Learns latent factors for users and products via truncated SVD to predict ratings on unseen user-product pairs |
| **6. Evaluation** | RMSE (rating-prediction accuracy) and Precision@10 (ranking quality) on a held-out test split |

## Project Structure

```
amazon_recsys/
├── data/                     # place the Kaggle CSV here (not committed)
├── outputs/                  # EDA plots + results_summary.txt (generated)
├── src/
│   ├── eda.py                 # data loading, cleaning, EDA plots
│   └── recommenders.py        # Popularity / Item-CF / SVD models + evaluation
├── run_pipeline.py            # end-to-end runnable script
├── requirements.txt
└── README.md
```

## How to Run

```bash
pip install -r requirements.txt
python run_pipeline.py --data data/ratings_Electronics.csv --out outputs
```

This will:
1. Load and clean the data
2. Print dataset statistics (before/after filtering)
3. Save EDA plots to `outputs/`
4. Train and evaluate all three models
5. Save a results summary table to `outputs/results_summary.txt`

## Sample Results (on synthetic smoke-test data — replace with your real run)

```
Model               RMSE      Precision@10
---------------------------------------------
Item-based CF       1.19      0.019
SVD (MF)            0.87      0.041
```

*(Run the pipeline on the real dataset and paste your actual numbers here —
this is the single most important thing recruiters look at.)*

## Key Takeaways / Talking Points for Interviews

- **Sparsity is the central challenge**: Amazon-scale rating matrices are
  >99% sparse; naive collaborative filtering doesn't scale without filtering
  and dimensionality reduction (SVD).
- **Popularity ≠ personalization**: the popularity baseline is a useful
  cold-start fallback but doesn't adapt to individual taste — a good example
  of why it's included as a baseline, not the final model.
- **Item-based vs. matrix factorization trade-off**: item-based CF is more
  interpretable ("recommended because you liked X"); SVD generally gives
  better rating-prediction accuracy but is a black box.
- **Next steps** (mentioned to show awareness of production concerns):
  handling cold-start users/items, incorporating implicit feedback
  (views/purchases, not just ratings), and scaling with approximate nearest
  neighbor search (e.g. FAISS) for real-time serving.

## Possible Extensions

- Hybrid model combining content-based features (product category, price) with CF
- Cold-start handling for new users/products
- A/B test simulation comparing model variants
- Deploy as a simple Streamlit demo app
