"""
End-to-end pipeline for the Amazon Product Recommendation System project.

Usage:
    python run_pipeline.py --data data/ratings_Electronics.csv

Download the dataset from:
    https://www.kaggle.com/datasets/saurav9786/amazon-product-reviews
and place the CSV inside the `data/` folder before running.
"""

import argparse
import os
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), "src"))

from eda import (
    load_data,
    basic_stats,
    filter_active_users_and_popular_items,
    plot_rating_distribution,
    plot_ratings_per_user,
    plot_ratings_per_product,
)
from recommenders import (
    PopularityRecommender,
    ItemBasedCF,
    SVDRecommender,
    train_test_split_ratings,
    evaluate_rmse,
    precision_at_k,
)


def main(data_path: str, out_dir: str):
    os.makedirs(out_dir, exist_ok=True)

    print(f"Loading data from {data_path} ...")
    df = load_data(data_path)

    print("\n--- Basic stats (raw data) ---")
    for k, v in basic_stats(df).items():
        print(f"{k}: {v}")

    print("\nFiltering to active users / popular products for tractable CF ...")
    df_filtered = filter_active_users_and_popular_items(
        df, min_user_ratings=5, min_product_ratings=10
    )
    print("\n--- Basic stats (filtered data) ---")
    for k, v in basic_stats(df_filtered).items():
        print(f"{k}: {v}")

    print("\nGenerating EDA plots ...")
    plot_rating_distribution(df_filtered, out_dir)
    plot_ratings_per_user(df_filtered, out_dir)
    plot_ratings_per_product(df_filtered, out_dir)
    print(f"Plots saved to {out_dir}")

    train_df, test_df = train_test_split_ratings(df_filtered, test_size=0.2)

    print("\n--- Model 1: Popularity baseline ---")
    pop_model = PopularityRecommender(min_ratings=5).fit(train_df)
    print("Top 10 overall recommendations:", pop_model.recommend(n=10))

    print("\n--- Model 2: Item-based Collaborative Filtering ---")
    item_cf = ItemBasedCF(k_neighbors=20).fit(train_df)
    sample_user = train_df["userId"].iloc[0]
    print(f"Sample recs for user {sample_user}:", item_cf.recommend(sample_user, n=10))
    rmse_cf = evaluate_rmse(item_cf, test_df)
    prec_cf = precision_at_k(item_cf, test_df, k=10)
    print(f"Item-based CF -> RMSE: {rmse_cf:.4f} | Precision@10: {prec_cf:.4f}")

    print("\n--- Model 3: SVD Matrix Factorization ---")
    svd_model = SVDRecommender(n_factors=20).fit(train_df)
    print(f"Sample recs for user {sample_user}:", svd_model.recommend(sample_user, n=10))
    rmse_svd = evaluate_rmse(svd_model, test_df)
    prec_svd = precision_at_k(svd_model, test_df, k=10)
    print(f"SVD -> RMSE: {rmse_svd:.4f} | Precision@10: {prec_svd:.4f}")

    print("\n--- Summary ---")
    summary = (
        f"{'Model':<20}{'RMSE':<10}{'Precision@10':<15}\n"
        f"{'-'*45}\n"
        f"{'Item-based CF':<20}{rmse_cf:<10.4f}{prec_cf:<15.4f}\n"
        f"{'SVD (MF)':<20}{rmse_svd:<10.4f}{prec_svd:<15.4f}\n"
    )
    print(summary)
    with open(os.path.join(out_dir, "results_summary.txt"), "w") as f:
        f.write(summary)
    print(f"Summary written to {os.path.join(out_dir, 'results_summary.txt')}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="data/ratings_Electronics.csv")
    parser.add_argument("--out", default="outputs")
    args = parser.parse_args()
    main(args.data, args.out)
