"""
EDA module for Amazon Product Recommendation System project.

Expects a CSV with columns: userId, productId, Rating, timestamp
(this matches the schema of the "Amazon Product Reviews" dataset on Kaggle:
https://www.kaggle.com/datasets/saurav9786/amazon-product-reviews)
"""

import os
import pandas as pd
import matplotlib.pyplot as plt

COLUMN_NAMES = ["userId", "productId", "Rating", "timestamp"]


def load_data(csv_path: str) -> pd.DataFrame:
    """Load the raw ratings CSV, adding column names if the file has none."""
    df = pd.read_csv(csv_path)

    # Some versions of this dataset ship without a header row.
    if list(df.columns[:4]) != COLUMN_NAMES:
        df = pd.read_csv(csv_path, names=COLUMN_NAMES, header=None)

    df["Rating"] = df["Rating"].astype(float)
    df["timestamp"] = pd.to_datetime(df["timestamp"], unit="s", errors="coerce")
    return df


def basic_stats(df: pd.DataFrame) -> dict:
    stats = {
        "n_ratings": len(df),
        "n_users": df["userId"].nunique(),
        "n_products": df["productId"].nunique(),
        "rating_min": df["Rating"].min(),
        "rating_max": df["Rating"].max(),
        "rating_mean": round(df["Rating"].mean(), 3),
        "sparsity_pct": round(
            100 * (1 - len(df) / (df["userId"].nunique() * df["productId"].nunique())), 4
        ),
    }
    return stats


def filter_active_users_and_popular_items(
    df: pd.DataFrame, min_user_ratings: int = 5, min_product_ratings: int = 10
) -> pd.DataFrame:
    """
    Recommendation quality collapses on extremely sparse data, so we keep only
    users who rated at least `min_user_ratings` items and products that received
    at least `min_product_ratings` ratings. This is standard practice for
    collaborative filtering on Amazon-scale review data.
    """
    user_counts = df["userId"].value_counts()
    product_counts = df["productId"].value_counts()

    active_users = user_counts[user_counts >= min_user_ratings].index
    popular_products = product_counts[product_counts >= min_product_ratings].index

    filtered = df[df["userId"].isin(active_users) & df["productId"].isin(popular_products)]
    return filtered.reset_index(drop=True)


def plot_rating_distribution(df: pd.DataFrame, out_dir: str):
    os.makedirs(out_dir, exist_ok=True)
    plt.figure(figsize=(6, 4))
    df["Rating"].value_counts().sort_index().plot(kind="bar", color="#2f6f4f")
    plt.title("Distribution of Ratings")
    plt.xlabel("Rating")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "rating_distribution.png"), dpi=150)
    plt.close()


def plot_ratings_per_user(df: pd.DataFrame, out_dir: str):
    os.makedirs(out_dir, exist_ok=True)
    counts = df["userId"].value_counts()
    plt.figure(figsize=(6, 4))
    plt.hist(counts, bins=50, color="#3b6fa0")
    plt.yscale("log")
    plt.title("Ratings per User (log scale)")
    plt.xlabel("Number of ratings")
    plt.ylabel("Number of users (log)")
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "ratings_per_user.png"), dpi=150)
    plt.close()


def plot_ratings_per_product(df: pd.DataFrame, out_dir: str):
    os.makedirs(out_dir, exist_ok=True)
    counts = df["productId"].value_counts()
    plt.figure(figsize=(6, 4))
    plt.hist(counts, bins=50, color="#c0703f")
    plt.yscale("log")
    plt.title("Ratings per Product (log scale)")
    plt.xlabel("Number of ratings")
    plt.ylabel("Number of products (log)")
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "ratings_per_product.png"), dpi=150)
    plt.close()
